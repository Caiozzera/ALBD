from unittest import TestCase

def Saldo_conta(saldo, saque):
    resto = saldo - saque
    return resto

class ClasseTestSaldo(TestCase):
    def test_valida_saldo(self):
        saldo = 900
        saque = 50
        self.assertEqual(Saldo_conta(saldo, saque),850 )

if __name__ == '_main_':
    Saldo_conta()
