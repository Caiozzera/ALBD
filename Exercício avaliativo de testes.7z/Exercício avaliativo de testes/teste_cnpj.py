from unittest import TestCase
import re

def informa_cnpj():
    cnpj=input("digite seu cnpj")
    valida_cnpj(cnpj)

class ClasseTESTE_CNPJ(TestCase):
    def test_valida_cnpj(self):
        self.assertTrue(valida_cnpj("10.653.700/0001-39"), True)

def valida_cnpj(cnpj):

    if not isinstance(cnpj,str):
        return False
    cpf = re.sub("[^0-9]",'',cnpj)

    if len(cpf) != 14:
        return False
    sum = 0
    weight = [5,4,3,2,9,8,7,6,5,4,3,2]

    for n in range(12):
        value =  int(cpf[n]) * weight[n]
        sum = sum + value


    verifyingDigit = sum % 11

    if verifyingDigit < 2 :
        firstVerifyingDigit = 0
    else:
        firstVerifyingDigit = 11 - verifyingDigit

    sum = 0
    weight = [6,5,4,3,2,9,8,7,6,5,4,3,2]
    for n in range(13):
        sum = sum + int(cpf[n]) * weight[n]

    verifyingDigit = sum % 11

    if verifyingDigit < 2 :
        secondVerifyingDigit = 0
    else:
        secondVerifyingDigit = 11 - verifyingDigit

    if cpf[-2:] == "%s%s" % (firstVerifyingDigit,secondVerifyingDigit):
        return True
    return False
